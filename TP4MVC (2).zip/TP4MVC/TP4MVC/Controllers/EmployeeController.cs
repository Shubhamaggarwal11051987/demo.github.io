﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TP4MVC.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            var emps = new List<string>() {"Deepak","Rahul","Ajay","sobhit" };
            ViewBag.employees = emps;
            return View();
        }
        public IActionResult Create()
        {
            return View();
        }
        
        public IActionResult Details()
        {
            return View();
        }
    }
}
