﻿using System;
namespace FirstConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            var stu = new Student("Ajay kumar",10000);
            var copy = new Student(stu);
            Console.WriteLine("Student Name : "+stu.Name);
            Console.WriteLine("Student Fee : "+stu.Fee);

            stu.Name = "sdfs";
            stu.Fee = 000;

            Console.WriteLine("------------------------");
            Console.WriteLine("Student Name : " + copy.Name);
            Console.WriteLine("Student Fee : " + copy.Fee);
            */

            //Student.Test();
            //  Student obj = new Student(5);
            try
            {
                var cust = new BankingCustomer("SBI00912", "Rakesh", 12000);
                Console.WriteLine("Account Number: " + cust.AccountNo);
                Console.WriteLine("Customer Name: " + cust.CustomerName);
                Console.WriteLine("Amount: " + cust.Amount);

                //cust.AccountNo = "dfsdf";
                cust.Amount -= 9000;
                Console.WriteLine("---------------------");
                Console.WriteLine("Account Number: " + cust.AccountNo);
                Console.WriteLine("Customer Name: " + cust.CustomerName);
                Console.WriteLine("Amount: " + cust.Amount);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }





            Console.Read();
        }

     
    }
}
