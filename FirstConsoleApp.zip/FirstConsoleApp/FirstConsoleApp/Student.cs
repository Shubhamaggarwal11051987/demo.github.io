﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstConsoleApp
{
    class Student
    {
        /*
        public string Name;
        public decimal Fee;
        public Student(string Name, decimal fee)
        {
            this.Name = Name;
            Fee = fee;
        }

        public Student(Student st)
        {
            Name = st.Name;
            Fee = st.Fee;
        }
        public void PrintName()
        {
            Console.WriteLine("Welcome Mr ."+Name);
        }
        */
        private Student()
        {
            Console.WriteLine("I am private constructor");
        }

        public Student(int x)
        {
            new Student();
            Console.WriteLine("I am pblic constructor");
        }
        public static void Test()
        {
            Console.WriteLine("I am test method !");
        }



    }
}
