﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstConsoleApp
{
    class Calculation
    {

        public Calculation()
        {
            Console.WriteLine("I am Constructor...");
        }
        public  void Addition(int x, int y)
        {
            int r = x + y;
            Console.WriteLine("Sum is : "+r);
        }
    }
}
