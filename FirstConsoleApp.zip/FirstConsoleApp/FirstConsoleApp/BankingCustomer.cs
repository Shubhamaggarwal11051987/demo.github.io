﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstConsoleApp
{
    class BankingCustomer
    {
        private string _AccountNo;
        public string CustomerName;
        private Decimal _Amount;

        public BankingCustomer(string AcNo, string name, decimal amount)
        {
            this._AccountNo = AcNo;
            this.CustomerName = name;
            this._Amount = amount;
        }

        public string AccountNo
        {
            get
            {
                return this._AccountNo;
            }
        }

        public decimal Amount
        {
            get { return this._Amount; }
            set
            {
                if (value >= 1000)
                {
                    this._Amount = value;
                }
                else
                {
                    throw new Exception("Invalid transaction !");
                }
            }
        }
    }
}
