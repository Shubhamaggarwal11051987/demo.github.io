﻿using System;

namespace MyLib
{
    public class Calculation
    {
        public void Product(int x, int y)
        {
            int r = x * y;
            Console.WriteLine("Output is : "+r);
        }
    }
}
