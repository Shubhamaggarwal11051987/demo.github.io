﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class PercentCalulator
    {
        public double Calculate(double amount, int percent) {
            return amount * percent / 100;
        }
    }
}
