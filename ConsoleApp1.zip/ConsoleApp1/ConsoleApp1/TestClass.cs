﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class TestClass
    {
        private TestClass(int x)
        {
            Console.WriteLine("I am Private Constructor...");
        }

        public TestClass()
        {
            Console.WriteLine("I am Public COnstructor...");

        }
        public  void Test()
        {
            
            Console.WriteLine("A Test Method !");
        }
    }
}
