﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp2
{
    class EmployeeOperation
    {
        public List<Employee> employees;
        public EmployeeOperation()
        {
            employees = new List<Employee>()
            {
        new Employee(){Id=1,Name="ajay",Gender="male",Salary=13000},
        new Employee(){Id=2,Name="rahul",Gender="male",Salary=14000},
        new Employee(){Id=3,Name="soni",Gender="female",Salary=17000}
            };
        }

        public void PrintEmployees()
        {
            Console.WriteLine("---------Employee Record--------");
            foreach(var em in employees)
            {
                Console.WriteLine($"Employee Id: {em.Id}, Employee Name: {em.Name}, Employee Gender:{em.Gender} Salary:{em.Salary}");
            }
        }
        public void AddEmployee(string name,string gender,double salary)
        {
            var emp = new Employee() {Id=employees.Count+1, Name = name, Gender = gender, Salary = salary };
            employees.Add(emp);
            Console.WriteLine("Employee added successfully....");
        }

        public bool DeleteEmployee(int id)
        {
            var emp = employees.SingleOrDefault(e => e.Id == id);
            if (emp!=null)
            {
                employees.Remove(emp);
                return true;
            }
            else
            {
                return false;
            }
        }

        public void SearchEmployeeByGender(string gender)
        {
            var result = employees.Where(e => e.Gender == gender);
            Console.WriteLine("------------Searched Employee-------------");
            foreach (var em in result)
            {
                Console.WriteLine($"Employee Id: {em.Id}, Employee Name: {em.Name}, Employee Gender:{em.Gender} Salary:{em.Salary}");
            }
        }

    }
}
