﻿using System;
using System.Collections.Generic;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            var emps = new EmployeeOperation();
            /*
            Console.WriteLine("Enter Employee Name ?");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Gender ?");
            string gender = Console.ReadLine();
            Console.WriteLine("Enter salary ?");
            double salary = double.Parse(Console.ReadLine());

            emps.AddEmployee(name, gender, salary);
            */

            /*
            Console.WriteLine("Enter Employee Id ?");
            int id = int.Parse(Console.ReadLine());
            var result = emps.DeleteEmployee(id);
            if(result)
            {
                Console.WriteLine("Employee Deleted Successfully...");
            }
            else
            {
                Console.WriteLine("Employee not found !");
            }

            */



            // emps.PrintEmployees();
            /*
            Console.WriteLine("Enter gender ? ");
            string gg = Console.ReadLine();
            emps.SearchEmployeeByGender(gg);
            */

            //w.a.p. to enter  2number and divid 1 by 2

            try
            {
                Console.WriteLine("Enter first number ?");
                int i = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter second number ?");
                int j = Int32.Parse(Console.ReadLine());

                int k = i / j;

                Console.WriteLine("Result : " + k);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            try
            {
                Console.WriteLine("Enter first number ?");
                int i = Int32.Parse(Console.ReadLine());

                Console.WriteLine("Enter second number ?");
                int j = Int32.Parse(Console.ReadLine());

                int k = i * j;

                Console.WriteLine("Product is : " + k);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }









        }
    }
}
